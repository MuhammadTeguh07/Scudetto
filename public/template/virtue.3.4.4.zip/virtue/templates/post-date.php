<div class="postmeta updated color_gray">
	<div class="postdate bg-lightgray headerfont">
		<meta itemprop="datePublished" content="<?php echo esc_attr( get_the_modified_date( 'c' ) ); ?>">
		<span class="postday"><?php echo get_the_date( 'j' ); ?></span>
		<?php echo esc_html( get_the_date( 'M Y' ) ); ?>
	</div>
</div>